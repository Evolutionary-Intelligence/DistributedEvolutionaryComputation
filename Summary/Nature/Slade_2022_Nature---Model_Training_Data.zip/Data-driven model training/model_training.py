
# coding: utf-8

# In[5]:


import sklearn
from sklearn import linear_model
from sklearn.linear_model import LogisticRegression
import numpy as np

train_data = np.load('training_data.npy', allow_pickle = True)
train_labels = np.load('train_labels.npy', allow_pickle = True)
print(train_data.shape, train_labels.shape)

classifier = LogisticRegression(penalty='l1', C=1.0, fit_intercept=False)
classifier.fit(train_data, train_labels)
print(classifier.coef_)

